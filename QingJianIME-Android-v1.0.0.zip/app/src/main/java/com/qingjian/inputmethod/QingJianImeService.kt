package com.qingjian.inputmethod

import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.inputmethod.EditorInfo

class QingJianImeService : InputMethodService() {
    private lateinit var keyboard: QingJianKeyboardView

    override fun onCreateInputView(): View {
        keyboard = QingJianKeyboardView(this)
        return keyboard
    }

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        if (::keyboard.isInitialized) keyboard.resetForNewField()
    }

    override fun onFinishInput() {
        if (::keyboard.isInitialized) keyboard.resetForNewField()
        super.onFinishInput()
    }
}
