package com.qingjian.inputmethod

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.inputmethodservice.InputMethodService
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.InputConnection
import kotlin.math.max
import kotlin.math.min

class QingJianKeyboardView(context: Context) : View(context) {
    private val ime = context as InputMethodService
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val composing = StringBuilder()
    private var candidates = listOf<String>()
    private var page = 0
    private var scriptZh = true
    private var mode = Mode.LETTERS
    private var lastCandidateRows = 0

    private enum class Mode { LETTERS, SYMBOLS, EMOJI }

    private val row1 = "qwertyuiop".toList()
    private val row2 = "asdfghjkl".toList()
    private val row3 = "zxcvbnm".toList()
    private val symbols1 = "1234567890".toList()
    private val symbols2 = listOf("@","#","%","&","*","-","+","(",")")
    private val symbols3 = listOf("!","\"","'",":",";","/","?","、")
    private val emoji = listOf("😀","😅","😂","🥰","😍","🤔","😎","😭","👍","🙏","🔥","⭐","🎉","❤️","✨","🌸","🌙","☕","🍜","🎵","📚","✏️","🏠","✅")

    private val keyRects = mutableListOf<Pair<RectF, String>>()
    private val candidateRects = mutableListOf<Pair<RectF, String>>()

    init {
        isFocusable = true
        setBackgroundColor(Color.rgb(245,245,245))
    }

    fun resetForNewField() {
        composing.clear()
        candidates = emptyList()
        page = 0
        mode = Mode.LETTERS
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        keyRects.clear()
        candidateRects.clear()
        val w = width.toFloat()
        val h = height.toFloat()
        paint.typeface = Typeface.create("sans", Typeface.NORMAL)

        // Candidate / composing strip
        paint.color = Color.WHITE
        c.drawRect(0f, 0f, w, dp(52f), paint)
        paint.color = Color.DKGRAY
        paint.textSize = dp(17f)
        val comp = if (scriptZh) composing.toString() else ""
        c.drawText(if (comp.isEmpty()) "青简输入法" else comp, dp(10f), dp(32f), paint)

        if (scriptZh && candidates.isNotEmpty()) {
            val start = page * 9
            for (i in 0 until min(9, candidates.size - start)) {
                val x = dp(120f) + i * dp(54f)
                val r = RectF(x, dp(4f), x + dp(50f), dp(48f))
                candidateRects.add(r to candidates[start+i])
                paint.color = Color.rgb(238,241,243)
                c.drawRoundRect(r, dp(8f), dp(8f), paint)
                paint.color = Color.DKGRAY
                paint.textSize = dp(19f)
                c.drawText("${i+1} ${candidates[start+i]}", r.left+dp(4f), r.top+dp(29f), paint)
            }
        }

        val top = dp(56f)
        val bottom = h - dp(4f)
        if (mode == Mode.EMOJI) {
            drawEmoji(c, top, bottom)
            return
        }
        if (mode == Mode.LETTERS) {
            drawKeyRow(c, row1, top, 1)
            drawKeyRow(c, row2, top + dp(48f), 1, sidePadding = 18f)
            drawKeyRow(c, row3, top + dp(96f), 1, leftExtra = "符", rightExtra = "⌫")
        } else {
            drawKeyRow(c, symbols1, top, 1)
            drawKeyRow(c, symbols2, top + dp(48f), 1, sidePadding = 12f)
            drawKeyRow(c, symbols3, top + dp(96f), 1, leftExtra = "😀", rightExtra = "⌫")
        }

        val y = bottom - dp(46f)
        val labels = listOf(if (mode == Mode.LETTERS) "123" else "ABC", if (scriptZh) "中" else "英", if (scriptZh) "，" else ",", if (scriptZh) "青简" else "space", if (scriptZh) "。" else ".", if (composing.isNotEmpty()) "确认" else "↵")
        val widths = listOf(54f,54f,42f,120f,42f,64f)
        var x = 2f
        for (i in labels.indices) {
            val ww = dp(widths[i])
            addKey(c, RectF(x, y, x+ww, y+dp(42f)), labels[i], labels[i])
            x += ww + dp(3f)
        }
    }

    private fun drawKeyRow(c: Canvas, keys: List<String>, y: Float, dummy: Int, sidePadding: Float = 0f, leftExtra: String? = null, rightExtra: String? = null) {
        var x = dp(sidePadding + 2f)
        if (leftExtra != null) {
            val r = RectF(x, y, x+dp(44f), y+dp(42f))
            addKey(c,r,leftExtra,leftExtra); x += dp(47f)
        }
        val usable = width - x - dp(sidePadding + 2f) - if (rightExtra != null) dp(47f) else 0f
        val gap = dp(3f)
        val kw = (usable - gap*(keys.size-1)) / keys.size
        for (k in keys) {
            val r=RectF(x,y,x+kw,y+dp(42f)); addKey(c,r,k,k); x += kw+gap
        }
        if (rightExtra != null) {
            val r=RectF(width-dp(sidePadding+46f),y,width-dp(sidePadding+2f),y+dp(42f))
            addKey(c,r,rightExtra,rightExtra)
        }
    }

    private fun drawEmoji(c: Canvas, top: Float, bottom: Float) {
        val cols=8
        val gap=dp(4f)
        val kw=(width-gap*(cols+1))/cols
        for (i in emoji.indices) {
            val row=i/cols; val col=i%cols
            val x=gap+col*(kw+gap); val y=top+row*dp(46f)
            val r=RectF(x,y,x+kw,y+dp(42f))
            addKey(c,r,emoji[i],emoji[i])
        }
    }

    private fun addKey(c: Canvas, r: RectF, label: String, value: String) {
        keyRects.add(r to value)
        paint.color = Color.WHITE
        c.drawRoundRect(r, dp(7f), dp(7f), paint)
        paint.color = Color.rgb(45,45,45)
        paint.textSize = dp(if (label.length > 2) 13f else 18f)
        val tw=paint.measureText(label)
        c.drawText(label, r.centerX()-tw/2, r.centerY()+dp(6f), paint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_UP) return true
        val x=e.x; val y=e.y
        for ((r,v) in candidateRects) if (r.contains(x,y)) { commitCandidate(v); return true }
        for ((r,v) in keyRects) if (r.contains(x,y)) { press(v); return true }
        return true
    }

    private fun press(k: String) {
        when {
            k=="⌫" -> backspace()
            k=="符" -> { mode=Mode.SYMBOLS; invalidate() }
            k=="😀" -> { mode=Mode.EMOJI; invalidate() }
            k=="123" -> { mode=Mode.SYMBOLS; invalidate() }
            k=="ABC" -> { mode=Mode.LETTERS; invalidate() }
            k=="中" -> { scriptZh=true; composing.clear(); candidates=emptyList(); invalidate() }
            k=="英" -> { scriptZh=false; composing.clear(); candidates=emptyList(); invalidate() }
            k=="青简" || k=="space" -> space()
            k=="确认" || k=="↵" -> enter()
            k=="，" -> direct("，")
            k=="。" -> direct("。")
            k=="," || k=="." -> direct(k)
            k=="\n" -> enter()
            else -> {
                if (scriptZh && mode==Mode.LETTERS && k.length==1 && k[0].isLetter()) {
                    composing.append(k.lowercase())
                    updateCandidates()
                    invalidate()
                } else {
                    direct(k)
                }
            }
        }
    }

    private fun updateCandidates() {
        val input=composing.toString()
        if (input.isEmpty()) { candidates=emptyList(); page=0; return }
        val result=ArrayList<Pair<String,Int>>()
        val seen=HashSet<String>()
        fun add(s:String, score:Int) { if (s.isNotEmpty() && seen.add(s)) result.add(s to score) }
        // Exact/prefix dictionary words.
        for (w in ImeData.words) {
            if (w.pinyin == input) add(w.text, 100000 + w.freq + w.text.length*20)
            else if (w.pinyin.startsWith(input)) add(w.text, 70000 + w.freq + w.text.length*10)
        }
        // Character candidates for first syllable.
        for (syl in ImeData.pinyinSyllables) {
            if (input.startsWith(syl)) {
                val cs=ImeData.chars[syl] ?: ""
                cs.forEachIndexed { i,ch -> add(ch.toString(), 50000-i*50) }
                break
            }
        }
        result.sortByDescending { it.second }
        candidates=result.take(48).map { it.first }
        page=0
    }

    private fun commitCandidate(s:String) {
        ic()?.commitText(s,1)
        composing.clear()
        candidates=emptyList()
        page=0
        invalidate()
    }

    private fun space() {
        if (composing.isNotEmpty()) {
            val idx=page*9
            val pick=candidates.getOrNull(idx)
            if (pick!=null) commitCandidate(pick) else { direct(composing.toString()); composing.clear(); candidates=emptyList(); invalidate() }
        } else direct(" ")
    }

    private fun enter() {
        if (composing.isNotEmpty()) { space(); return }
        ic()?.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_ENTER))
        ic()?.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, android.view.KeyEvent.KEYCODE_ENTER))
    }

    private fun backspace() {
        if (composing.isNotEmpty()) {
            composing.deleteCharAt(composing.length-1); updateCandidates(); invalidate()
        } else {
            ic()?.deleteSurroundingText(1,0)
        }
    }

    private fun direct(s:String) {
        ic()?.commitText(s,1)
    }

    private fun ic(): InputConnection? = ime.currentInputConnection

    private fun dp(v:Float)=v*resources.displayMetrics.density
}
