package com.qingjian.inputmethod

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.TextView

class QingJianSettingsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val t = TextView(this)
        t.text = "青简输入法\n\n这是由 Grok 原型转换的原生 Android 输入法。\n\n支持：中文拼音、候选词、英文、数字、符号、Emoji。"
        t.textSize = 18f
        t.setPadding(40, 60, 40, 40)
        t.gravity = Gravity.CENTER_VERTICAL
        setContentView(t)
    }
}
